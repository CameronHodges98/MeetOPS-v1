import { neon } from '@neondatabase/serverless'
import { drizzle } from 'drizzle-orm/neon-http'
import * as schema from './schema'

// Neon's serverless driver uses HTTP instead of a persistent TCP connection.
// This is required for Vercel's serverless functions which don't maintain
// long-lived connections. Each function invocation gets a fresh HTTP request
// to Neon, which handles pooling on its end.
//
// We export a single `db` instance. In serverless, this module is re-evaluated
// per cold start — that's fine. The neon() call is cheap (no TCP handshake).

if (!process.env.DATABASE_URL) {
  throw new Error(
    'DATABASE_URL is not set. Copy .env.example to .env.local and fill in your Neon connection string.'
  )
}

const sql = neon(process.env.DATABASE_URL)

export const db = drizzle(sql, {
  schema,
  // Log queries in development only — never in production (leaks SQL to logs)
  logger: process.env.NODE_ENV === 'development',
})

export type DB = typeof db
