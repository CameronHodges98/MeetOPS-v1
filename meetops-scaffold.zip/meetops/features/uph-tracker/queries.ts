import { useQuery } from '@tanstack/react-query'

interface UphRecord {
  employeeId: number
  employeeName: string
  jobTitle: string
  paylocityId: string
  totalPoints: number
  totalActions: number
  daysWorked: number
}

export function useUphData(dateFrom: string, dateTo: string, jobTitle?: string | null) {
  return useQuery<UphRecord[]>({
    queryKey: ['uph', dateFrom, dateTo, jobTitle],
    queryFn: async () => {
      const params = new URLSearchParams({ from: dateFrom, to: dateTo })
      if (jobTitle) params.set('jobTitle', jobTitle)
      const res = await fetch(`/api/uph?${params}`)
      if (!res.ok) throw new Error('Failed to fetch UPH data')
      return res.json()
    },
    staleTime: 60_000, // Re-fetch at most once per minute
    enabled: Boolean(dateFrom && dateTo),
  })
}
