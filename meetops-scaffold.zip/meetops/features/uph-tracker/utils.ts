// Pure utility functions for UPH tracker
// No React imports — this file is independently testable
export {}
